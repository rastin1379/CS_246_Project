#include "chessview.h"

int main() {
	ChessView program {};
	program.run();
}
