#ifndef POSITION_H
#define POSITION_H

class Position {
	private:
	int x, y;

	public:
	Position(int x, int y);
	int get_x();
	int get_y();
	int distance_squared(Position p);
};

#endif
